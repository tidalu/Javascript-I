// function save() {
//     console.log('clicked');
// }

// let inputBtn = document.getElementById('input-btn');

// inputBtn.addEventListener("click", function(){
//     console.log('clicked bu whatever')
// })












const inputBtn = document.querySelector('#input-btn');
const ulEL = document.querySelector('#ul-el');
let myLead = [];
const inputEl = document.querySelector('#input-el');

inputBtn.addEventListener("click", function(){
    myLead.push(inputEl.value);
    inputEl.value = "";
    // console.log(myLead);
    renderLeads();
})



function renderLeads(){
    let listItems = ""
    for(let i = 0; i < myLead.length; i++){
        listItems += `<li>
                        <a href='${myLead[i]}' target='_blank'>
                        ${myLead[i]}
                        </a>
                    </li>`;
        // console.log(listItems);
        // second way
        // const li = document.createElement('li');
        // li.textContent = myLead[i];
        // ulEl.append(li);
    }
    ulEL.innerHTML = listItems;
    
}



// const scr = document.createElement('script');

// scr.textContent = "alert('hello')";
// body.append('script')
















//template strings/literals

const recipient = "John";
const sender = "Jane Doe "; 

const main = `
hey ${recipient} 
!how are you 
doing today? ${sender}`;

console.log(main);







// let box = document.getElementById('box');

// box.addEventListener("click", function(){
//     console.log('I want to open the box');
// })

// const playerName = "per";
// let credits = 45;
// credits = credits - 10;


// const basePrice = 520;
// const discount = 120;
// let shippingCost = 12;
// let shippingTime = "5 - 12 days";

// shippingCost = 15;
// shippingTime = "7-14 days";


// let fullPrice = basePrice - discount + shippingCost;

// console.log(fullPrice);

// const container = document.getElementById('container');

// container.innerHTML = "<button onclick='buy()'> Click Me </button>";


// function buy() {
//     container.innerHTML += "<p>Thank you for your purchase!</p>";
// }







